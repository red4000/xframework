#ifndef CVARS_H
#define CVARS_H

void InitializeCVars();
void SaveCVars();

#endif
