#ifndef AIMBOT_H
#define AIMBOT_H

#include "tzar.h"
#include "game.h"

class RandomOffsetCfg {
public:
	float    minLength, maxLength, velocityFrac, directionFrac;
	FVector3 scale;
};

class MultiPointCfg {
public:
	int      points;
	float    minLength, maxLength, velocityFrac, directionFrac;
	FVector3 scale;
};

class BoneCfg {
public:
	int             id, enabled, autoWall;
	RandomOffsetCfg randomOffset;
	MultiPointCfg   point;
	float           prediction, zAdjust, penetration;
};

void InjectCmd();
bool AimbotActive();
void AimbotPreFrame();
void AimAtEntityFrame(Entity *ent, PlayerInfo *i);
void AimbotPostFrame();
bool GetAimbotAngles(TVec3 *res);

extern int         aimbot, silentAim, autoFire, minAfterburst, maxAfterburst, fireStartDelay, fireDelay, aimBone, targetLock, aimSort, aimKeyEnabled, aimKey, aimAtFirstTarget, randomOffsetEnable;
extern float       aimFOV, aimZAdjust, targetFitness, targetPower, localPrediction, randomOffsetMinLength, randomOffsetMaxLength;
extern BoneCfg     boneCfg[MAX_TAG];

extern DVector3    targetPosition;
extern TVec3       targetAngles;
extern Entity     *targetEnt;
extern PlayerInfo *targetPi;

#endif
