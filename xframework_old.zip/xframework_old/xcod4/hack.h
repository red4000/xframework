#ifndef HACK_H
#define HACK_H

void InitializeHack();
void DestroyHack();
void RenderHackFrame();

#endif
