#ifndef CHAMS_H
#define CHAMS_H

#include "drender.h"

void InitializeChams();
HRESULT __fastcall hDrawIndexedPrimitive(void *thisptr, int edx, LPDIRECT3DDEVICE9 pDevice, D3DPRIMITIVETYPE Type, INT BaseIndex, UINT MinIndex, UINT NumVertices, UINT StartIndex, UINT primCount);

void HookD3D9();
void UnhookD3D9();

extern int playerChams, onlyEnemyChams, visChamStyle, invisChamStyle, wallHack, weaponChams, visWeaponChamStyle, invisWeaponChamStyle, wallChams;
extern _Color enemyVisCol, enemyInvisCol, friendlyVisCol, friendlyInvisCol;

#endif
