#ifndef MENU_H
#define MENU_H

void InitializeMenu();
void DestroyMenu();
void MenuFrame();

extern Window *menuWindow;

#endif
