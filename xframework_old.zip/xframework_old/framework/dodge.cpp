#include "framework.h"
#include "game.h"

int   dodgeEnabled, dodgeMode;
float dodgeThreat;

int DodgeEntity(Entity *ent, PlayerInfo *i) {
	return 0;
}
