#ifndef PATTERN_H
#define PATTERN_H

DWORD FindPattern(DWORD dwAddress, DWORD dwSize, BYTE *pbMask, char *szMask);

#endif
