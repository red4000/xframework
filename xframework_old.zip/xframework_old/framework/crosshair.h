#ifndef CROSSHAIR_H
#define CROSSHAIR_H

void RenderCrosshair();

extern int    crosshairEnabled, crosshairType, crosshairSize;
extern _Color crosshairCol, crosshairCol2;

#endif
