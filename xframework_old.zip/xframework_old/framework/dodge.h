#ifndef DODGE_H
#define DODGE_H

int DodgeEntity(Entity *ent, PlayerInfo *i);

extern int   dodgeEnabled, dodgeMode;
extern float dodgeThreat;

#endif
