#ifndef FCVARS_H
#define FCVARS_H

extern CVar aimHeader,
			espHeader,
			radarHeader,
			miscHeader,
			colorHeader;

#endif
