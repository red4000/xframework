#ifndef LDE64_H
#define LDE64_H

extern "C" size_t __stdcall LDE(const void *lpData, unsigned int size);
#endif
