#ifndef FRENDER_H
#define FRENDER_H

void InitializeFrameworkResources();
void ReleaseFrameworkResources();
void RenderFrameworkFrame();

#endif
