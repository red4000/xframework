#ifndef MEMORY_H
#define MEMORY_H

DWORD GetModuleSize(HMODULE mod);

#endif
