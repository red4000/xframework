#ifndef CONTROLFP_H
#define CONTROLFP_H

void ChangeFPUPrecision(int to);

#endif
