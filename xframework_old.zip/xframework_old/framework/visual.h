#ifndef VISUAL_H
#define VISUAL_H

void RenderVisuals();

#endif
