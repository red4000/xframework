#ifndef SESP_H
#define SESP_H

void PlaySoundESP(Entity *ent, PlayerInfo *i);

extern int   soundEsp, soundEspDelay;
extern float soundEspFOV;

#endif
