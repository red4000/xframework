#ifndef CLOCK_H
#define CLOCK_H

void InitializeClock();
void RenderClock();

extern int clockEnabled, clockType, clockSize;

#endif
