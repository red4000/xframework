#ifndef SHA3_H
#define SHA3_H

std::string SHA3(std::string str);

#endif
