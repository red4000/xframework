#ifndef DAUTH_H
#define DAUTH_H

//#include "antidump.h"

//DECLARE_WIPABLE_FUNC(void, AuthenticateLoader())
void AuthenticateLoader();

#endif